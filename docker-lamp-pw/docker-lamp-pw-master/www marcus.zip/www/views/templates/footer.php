<footer class="site-footer">
        <div class="container-fluid">
          <div class="row">
            <div class="col-sm-12 col-md-6">
              <h6>Sobre</h6>
              <p class="text-justify">Lorem ipsum dolor sit, amet consectetur adipisicing elit. Voluptatem blanditiis doloribus dolore dolorem quia facere quasi maxime! Animi, officiis. Amet?</p>
          <hr>
        </div>
            <div class="col-md-4 col-sm-6 col-xs-12">
              <ul class="social-icons">
                <li><a class="facebook" href="https://pt-br.facebook.com/"><i class="bi bi-facebook"></i></i></a></li>
                <li><a class="twitter" href="https://twitter.com/"><i class="bi bi-twitter"></i></i></a></li>
                <li><a class="instagram" href="https://www.instagram.com/accounts/login/?next=%2Fmarcus.barcelos%2F&source=desktop_nav"><i class="bi bi-instagram"></i></i></a></li>
                <li><a class="linkedin" href="https://www.linkedin.com/authwall?trk=gf&trkInfo=AQGR5l9JKD_30wAAAYHFRP4Q7KsxRpkXZ6KqgsLbTF6u5SYxNn3KgU6rtGyAfMtrefYg7v8ssh9rKbvbjwpmJFfRmrpVFWC_0DPJ2iSgGa5tcKwXb0xp8bbT0ILluP5JUyaOlqE=&original_referer=&sessionRedirect=https%3A%2F%2Fwww.linkedin.com%2Fin%2Fmarcus-vin%25C3%25ADcius-barcelos-b4baa4235%2F"><i class="bi bi-linkedin"></i></a></li>   
              </ul>
            </div>
          </div>
        </div>
  </footer>  